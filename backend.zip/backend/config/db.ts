import mongoose from "mongoose";

const mongoUrl = process.env.MONGO_URL;
if (!mongoUrl) {
  throw new Error("❌ MONGO_URL is not defined in environment variables");
}

const connectDB = async () => {
  try {
    await mongoose.connect(mongoUrl);
    console.log("✅ Connected to MongoDB");
  } catch (err) {
    console.error("❌ Failed to connect to MongoDB", err);
    process.exit(1);
  }
};

export default connectDB;