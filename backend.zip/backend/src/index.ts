// Load env variables first thing
import dotenv from "dotenv";
dotenv.config()
import express from "express";

// Routes import here if needed
import connectDB from "../config/db";

// Connect to DB
connectDB();

const app = express();
const PORT = process.env.PORT || 5000;

app.get("/", (_req, res) => {
  res.send("hello world");
});

app.listen(PORT, () => {
  console.log(`⚙️ Server is running on http://localhost:${PORT}`);
});